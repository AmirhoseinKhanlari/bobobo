void print() {
    System.out.println("Hello World!");
}
