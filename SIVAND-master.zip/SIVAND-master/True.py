length = float(input("Enter the length of the rectangle: "))
width = float(input("Enter the width of the rectangle: "))
permiter = 0
area = 0
area = length * width
area = 2*(length+width)